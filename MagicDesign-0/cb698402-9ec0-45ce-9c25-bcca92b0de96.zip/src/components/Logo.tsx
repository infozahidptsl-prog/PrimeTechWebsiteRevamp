import React from 'react';
import { brandName } from '../data/site';

type LogoProps = {light?: boolean;};

export function Logo({ light = false }: LogoProps) {
  return (
    <a
      href="#top"
      aria-label={`${brandName} home`}
      className={`text-[30px] font-bold leading-none tracking-tight ${light ? 'text-white' : 'text-brand'}`}>
      
      {brandName}
    </a>);

}